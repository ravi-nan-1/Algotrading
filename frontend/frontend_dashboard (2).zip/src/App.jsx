import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = 'http://localhost:8000';

export default function App() {
  const [status, setStatus] = useState('unknown');
  const [trades, setTrades] = useState([]);
  const [openTrades, setOpenTrades] = useState([]);
  const [logs, setLogs] = useState([]);
  const [ticker, setTicker] = useState({});
  const [currentPnL, setCurrentPnL] = useState(0);
  const [todayPnL, setTodayPnL] = useState(0);
  const [tickers, setTickers] = useState([]);
  const [newTickersText, setNewTickersText] = useState("");

  const fetchStatus = async () => {
    const res = await axios.get(`${API_URL}/status`);
    setStatus(res.data.algo_status);
  };

  const fetchTrades = async () => {
    const res = await axios.get(`${API_URL}/trades`);
    setTrades(res.data);
  };

  const fetchOpenTrades = async () => {
    const res = await axios.get(`${API_URL}/open-trades`);
    setOpenTrades(res.data);
  };

  const fetchLogs = async () => {
    const res = await axios.get(`${API_URL}/logs`);
    setLogs(res.data.logs);
  };

  const fetchTicker = async () => {
    const res = await axios.get(`${API_URL}/ticker`);
    setTicker(res.data);
  };

  const fetchPnLs = async () => {
    const res1 = await axios.get(`${API_URL}/pnl/current`);
    const res2 = await axios.get(`${API_URL}/pnl/today`);
    setCurrentPnL(res1.data.current_pnl);
    setTodayPnL(res2.data.pnl_today);
  };

  const fetchTickers = async () => {
    const res = await axios.get(`${API_URL}/tickers`);
    setTickers(res.data.tickers);
    setNewTickersText(res.data.tickers.join("\n"));
  };

  const updateTickers = async () => {
    const updated = newTickersText.split("\n").map(t => t.trim()).filter(Boolean);
    await axios.post(`${API_URL}/tickers`, { tickers: updated });
    fetchTickers();
  };

  const startAlgo = async () => {
    await axios.post(`${API_URL}/algo/start`);
    fetchStatus();
  };

  const stopAlgo = async () => {
    await axios.post(`${API_URL}/algo/stop`);
    fetchStatus();
  };

  useEffect(() => {
    fetchStatus();
    fetchTrades();
    fetchOpenTrades();
    fetchLogs();
    fetchTicker();
    fetchPnLs();
    fetchTickers();
    const interval = setInterval(() => {
      fetchTicker();
      fetchPnLs();
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Algo Trading Dashboard</h1>
      <p><strong>Status:</strong> {status}</p>
      <button onClick={startAlgo}>Start Algo</button>
      <button onClick={stopAlgo} style={{ marginLeft: 10 }}>Stop Algo</button>

      <h2 style={{ marginTop: 30 }}>Live Ticker</h2>
      <p>NIFTY: {ticker.NIFTY} | BANKNIFTY: {ticker.BANKNIFTY}</p>

      <h2 style={{ marginTop: 30 }}>Live PnL</h2>
      <p><strong>Current Trade PnL:</strong> ₹{currentPnL}</p>
      <p><strong>Today's PnL:</strong> ₹{todayPnL}</p>

      <h2 style={{ marginTop: 30 }}>Open Trades</h2>
      <table border="1" cellPadding="8" style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead>
          <tr>
            <th>Symbol</th><th>Entry Time</th><th>Buy Price</th><th>Target</th><th>Status</th>
          </tr>
        </thead>
        <tbody>
          {openTrades.map((trade, i) => (
            <tr key={i}>
              <td>{trade.Symbol}</td>
              <td>{trade['Entry Time']}</td>
              <td>{trade['Buy Price']}</td>
              <td>{trade['Target Price']}</td>
              <td>{trade['Trade Status']}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2 style={{ marginTop: 30 }}>Tracked Tickers</h2>
      <textarea
        rows="5"
        style={{ width: '100%' }}
        value={newTickersText}
        onChange={e => setNewTickersText(e.target.value)}
      />
      <button onClick={updateTickers} style={{ marginTop: 10 }}>Update Tickers</button>

      <h2 style={{ marginTop: 30 }}>Logs</h2>
      <pre style={{ background: '#111', color: '#0f0', padding: 10, maxHeight: 200, overflowY: 'auto' }}>
        {logs.join('\n')}
      </pre>
    </div>
  );
}